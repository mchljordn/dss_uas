"""
Decision Support System - Inventory Management
Sistem Pendukung Keputusan untuk Manajemen Stok Barang
Mengatasi Overstock dan Understock dengan Predictive Analytics
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Time series models
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Page configuration
st.set_page_config(
    page_title="DSS - Inventory Management",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        padding: 1rem;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        border-left: 5px solid #1f77b4;
    }
    .warning-box {
        background-color: #fff3cd;
        padding: 1rem;
        border-radius: 5px;
        border-left: 5px solid #ffc107;
    }
    .success-box {
        background-color: #d4edda;
        padding: 1rem;
        border-radius: 5px;
        border-left: 5px solid #28a745;
    }
    .danger-box {
        background-color: #f8d7da;
        padding: 1rem;
        border-radius: 5px;
        border-left: 5px solid #dc3545;
    }
</style>
""", unsafe_allow_html=True)

# Session state initialization
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'forecasts_generated' not in st.session_state:
    st.session_state.forecasts_generated = False

# Helper Functions
@st.cache_data
def load_data(file):
    """Load and preprocess sales data"""
    df = pd.read_csv(file)
    
    # Handle cancelled transactions
    df['IsCancelled'] = df['TransactionNo'].astype(str).str.startswith('C')
    df = df[~df['IsCancelled']].copy()
    
    # Remove negative values
    df = df[(df['Quantity'] > 0) & (df['Price'] > 0)].copy()
    
    # Convert date and calculate revenue
    df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')
    df['Revenue'] = df['Price'] * df['Quantity']
    
    return df

@st.cache_data
def prepare_time_series(df):
    """Prepare daily aggregated time series"""
    daily_sales = df.groupby('Date').agg({
        'TransactionNo': 'count',
        'Quantity': 'sum',
        'Revenue': 'sum'
    }).reset_index()
    
    daily_sales.columns = ['Date', 'NumTransactions', 'TotalQuantity', 'TotalRevenue']
    daily_sales = daily_sales.sort_values('Date').reset_index(drop=True)
    
    # Set date as index and fill missing dates
    ts_data = daily_sales.set_index('Date')
    ts_data = ts_data.asfreq('D', method='ffill')
    
    return ts_data

@st.cache_data
def calculate_product_stats(df):
    """Calculate product-level statistics"""
    product_sales = df.groupby(['ProductNo', 'ProductName']).agg({
        'TransactionNo': 'count',
        'Quantity': 'sum',
        'Revenue': 'sum',
        'Price': 'mean'
    }).reset_index()
    
    product_sales.columns = ['ProductNo', 'ProductName', 'NumTransactions', 
                            'TotalQuantity', 'TotalRevenue', 'AvgPrice']
    
    product_sales = product_sales.sort_values('TotalRevenue', ascending=False).reset_index(drop=True)
    
    # ABC Classification
    product_sales['RevenuePct'] = (product_sales['TotalRevenue'] / 
                                   product_sales['TotalRevenue'].sum() * 100)
    product_sales['CumulativePct'] = product_sales['RevenuePct'].cumsum()
    
    def classify_abc(cum_pct):
        if cum_pct <= 80:
            return 'A - Best Sellers (Top 80%)'
        elif cum_pct <= 95:
            return 'B - Moderate Sellers'
        else:
            return 'C - Slow Movers'
    
    product_sales['Category'] = product_sales['CumulativePct'].apply(classify_abc)
    
    return product_sales

def train_arima_model(train_data, order=(2,1,2)):
    """Train ARIMA model"""
    model = ARIMA(train_data, order=order)
    model_fit = model.fit()
    return model_fit

def train_exponential_smoothing(train_data):
    """Train Exponential Smoothing model"""
    try:
        model = ExponentialSmoothing(
            train_data,
            seasonal_periods=7,
            trend='add',
            seasonal='add',
            initialization_method='estimated'
        )
        model_fit = model.fit(optimized=True)
    except:
        model = ExponentialSmoothing(train_data, trend='add', seasonal=None)
        model_fit = model.fit(optimized=True)
    return model_fit

def train_moving_average(train_data, window_size=7):
    """Train Moving Average model"""
    # Calculate moving average on training data
    ma_values = train_data.rolling(window=window_size).mean()
    # Return last MA value for forecasting
    return ma_values.iloc[-window_size:].mean() if len(ma_values) >= window_size else train_data.mean()

def calculate_stock_recommendation(forecast, safety_stock_pct=20, lead_time_days=7):
    """Calculate recommended stock levels"""
    # Average daily demand from forecast
    avg_daily_demand = forecast.mean()
    
    # Safety stock (buffer)
    safety_stock = avg_daily_demand * (safety_stock_pct / 100) * lead_time_days
    
    # Reorder point
    reorder_point = (avg_daily_demand * lead_time_days) + safety_stock
    
    # Economic order quantity (simplified)
    total_demand = forecast.sum()
    
    return {
        'avg_daily_demand': avg_daily_demand,
        'safety_stock': safety_stock,
        'reorder_point': reorder_point,
        'total_30day_demand': total_demand,
        'recommended_stock': total_demand + safety_stock
    }

def detect_stock_issues(current_stock, reorder_point, max_stock):
    """Detect overstock and understock situations"""
    if current_stock <= reorder_point:
        return 'UNDERSTOCK', 'danger'
    elif current_stock >= max_stock:
        return 'OVERSTOCK', 'warning'
    else:
        return 'OPTIMAL', 'success'

# ============================================================================
# MAIN APP
# ============================================================================

# Header
st.markdown('<div class="main-header">📦 Decision Support System - Inventory Management</div>', 
            unsafe_allow_html=True)

st.markdown("""
### 🎯 Tujuan Sistem
Sistem ini membantu manajer dalam:
- **Menghindari Overstock**: Mencegah biaya penyimpanan berlebih dan risiko barang tidak laku
- **Menghindari Understock**: Memastikan stok cukup untuk memenuhi permintaan pelanggan
- **Optimasi Stok**: Rekomendasi jumlah stok optimal berdasarkan prediksi permintaan
- **Strategi Promosi**: Identifikasi produk dan waktu optimal untuk promosi
""")

# Sidebar
with st.sidebar:
    st.header("⚙️ Pengaturan")
    
    # File upload
    uploaded_file = st.file_uploader("Upload Data Penjualan (CSV)", type=['csv'])
    
    if uploaded_file is not None:
        st.session_state.data_loaded = True
    
    st.markdown("---")
    
    # Forecasting parameters
    st.subheader("📊 Parameter Forecasting")
    forecast_days = st.slider("Periode Prediksi (hari)", 7, 90, 30)
    safety_stock_pct = st.slider("Safety Stock (%)", 10, 50, 20, 
                                 help="Buffer stok untuk mengantisipasi lonjakan permintaan")
    lead_time_days = st.slider("Lead Time (hari)", 1, 14, 7,
                               help="Waktu tunggu dari pemesanan hingga barang tiba")
    
    st.markdown("---")
    
    # Model selection
    st.subheader("🤖 Pilih Model")
    model_choice = st.selectbox("Model Forecasting", 
                                ['Moving Average', 'ARIMA', 'Exponential Smoothing', 'Auto (Best Model)'])
    
    st.markdown("---")
    
    # Stock alert thresholds
    st.subheader("🚨 Alert Threshold")
    understock_threshold = st.slider("Understock Alert (%)", 10, 50, 30)
    overstock_threshold = st.slider("Overstock Alert (%)", 100, 300, 150)

# Main content
if not st.session_state.data_loaded:
    st.info("👈 Silakan upload file CSV data penjualan untuk memulai analisis")
    
    # Show sample data format
    st.subheader("📋 Format Data yang Dibutuhkan")
    sample_data = pd.DataFrame({
        'TransactionNo': ['536365', '536366', 'C536367'],
        'Date': ['12/1/2010', '12/1/2010', '12/1/2010'],
        'ProductNo': ['85123A', '71053', '84406B'],
        'ProductName': ['WHITE HANGING HEART', 'WHITE METAL LANTERN', 'CREAM CUPID HEARTS'],
        'Price': [2.55, 3.39, 2.75],
        'Quantity': [6, 6, 8],
        'CustomerNo': ['17850', '17850', '17850'],
        'Country': ['United Kingdom', 'United Kingdom', 'United Kingdom']
    })
    st.dataframe(sample_data)
    
else:
    # Load data
    df = load_data(uploaded_file)
    ts_data = prepare_time_series(df)
    product_stats = calculate_product_stats(df)
    
    # Tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📈 Dashboard", 
        "🔮 Forecasting & Stock", 
        "📦 Manajemen Produk",
        "⚠️ Alert & Rekomendasi",
        "📊 Analisis Detail"
    ])
    
    # ========================================================================
    # TAB 1: DASHBOARD
    # ========================================================================
    with tab1:
        st.header("📈 Overview Bisnis")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        total_revenue = df['Revenue'].sum()
        total_transactions = df['TransactionNo'].nunique()
        total_products = df['ProductNo'].nunique()
        avg_daily_revenue = ts_data['TotalRevenue'].mean()
        
        with col1:
            st.metric("Total Revenue", f"£{total_revenue:,.0f}")
        with col2:
            st.metric("Total Transaksi", f"{total_transactions:,}")
        with col3:
            st.metric("Jumlah Produk", f"{total_products:,}")
        with col4:
            st.metric("Avg Daily Revenue", f"£{avg_daily_revenue:,.0f}")
        
        st.markdown("---")
        
        # Revenue trend
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("📊 Trend Penjualan")
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=ts_data.index,
                y=ts_data['TotalRevenue'],
                mode='lines',
                name='Daily Revenue',
                line=dict(color='#1f77b4', width=2),
                fill='tozeroy',
                fillcolor='rgba(31, 119, 180, 0.2)'
            ))
            fig.update_layout(
                height=400,
                hovermode='x unified',
                xaxis_title='Tanggal',
                yaxis_title='Revenue (£)'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("🏆 Top 5 Produk")
            top5 = product_stats.head(5)[['ProductName', 'TotalRevenue']]
            top5['Revenue'] = top5['TotalRevenue'].apply(lambda x: f"£{x:,.0f}")
            st.dataframe(
                top5[['ProductName', 'Revenue']].reset_index(drop=True),
                hide_index=True,
                use_container_width=True
            )
        
        # ABC Analysis
        st.markdown("---")
        st.subheader("📊 ABC Classification")
        
        abc_summary = product_stats.groupby('Category').agg({
            'ProductNo': 'count',
            'TotalRevenue': 'sum'
        }).reset_index()
        abc_summary.columns = ['Category', 'Jumlah Produk', 'Total Revenue']
        abc_summary['Revenue %'] = (abc_summary['Total Revenue'] / 
                                    abc_summary['Total Revenue'].sum() * 100).round(1)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.pie(
                abc_summary,
                values='Jumlah Produk',
                names='Category',
                title='Distribusi Produk per Kategori',
                color_discrete_sequence=px.colors.qualitative.Set2
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            fig = px.bar(
                abc_summary,
                x='Category',
                y='Revenue %',
                title='Kontribusi Revenue per Kategori',
                color='Category',
                color_discrete_sequence=px.colors.qualitative.Set2,
                text='Revenue %'
            )
            fig.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
            st.plotly_chart(fig, use_container_width=True)
    
    # ========================================================================
    # TAB 2: FORECASTING & STOCK
    # ========================================================================
    with tab2:
        st.header("🔮 Forecasting & Rekomendasi Stok")
        
        if st.button("🚀 Generate Forecast", type="primary"):
            with st.spinner("Memproses forecasting..."):
                # Train-test split
                train_size = int(len(ts_data) * 0.8)
                train_data = ts_data['TotalRevenue'][:train_size]
                test_data = ts_data['TotalRevenue'][train_size:]
                
                # Train models
                ma_avg = train_moving_average(train_data)
                arima_model = train_arima_model(train_data)
                es_model = train_exponential_smoothing(train_data)
                
                # Test predictions
                ma_test_pred = pd.Series([ma_avg] * len(test_data), index=test_data.index)
                arima_test_pred = arima_model.forecast(steps=len(test_data))
                es_test_pred = es_model.forecast(steps=len(test_data))
                
                # Calculate errors
                mae_ma = mean_absolute_error(test_data, ma_test_pred)
                mae_arima = mean_absolute_error(test_data, arima_test_pred)
                mae_es = mean_absolute_error(test_data, es_test_pred)
                
                # Select best model
                if model_choice == 'Moving Average':
                    best_model = None
                    best_model_name = 'Moving Average'
                    ma_value = train_moving_average(ts_data['TotalRevenue'])
                elif model_choice == 'ARIMA':
                    best_model = arima_model
                    best_model_name = 'ARIMA'
                elif model_choice == 'Exponential Smoothing':
                    best_model = es_model
                    best_model_name = 'Exponential Smoothing'
                else:
                    errors = {'Moving Average': mae_ma, 'ARIMA': mae_arima, 'Exponential Smoothing': mae_es}
                    best_model_name = min(errors, key=errors.get)
                    if best_model_name == 'ARIMA':
                        best_model = arima_model
                    elif best_model_name == 'Exponential Smoothing':
                        best_model = es_model
                    else:
                        best_model = None
                        ma_value = train_moving_average(ts_data['TotalRevenue'])
                
                # Retrain on full data
                full_data = ts_data['TotalRevenue']
                if best_model_name == 'Moving Average':
                    final_model = None
                    ma_value = train_moving_average(full_data)
                elif best_model_name == 'ARIMA':
                    final_model = ARIMA(full_data, order=(2,1,2)).fit()
                else:
                    final_model = train_exponential_smoothing(full_data)
                
                # Future forecast
                future_dates = pd.date_range(
                    start=ts_data.index[-1] + timedelta(days=1),
                    periods=forecast_days,
                    freq='D'
                )
                
                if best_model_name == 'Moving Average':
                    future_forecast = pd.Series([ma_value] * forecast_days, index=future_dates)
                else:
                    future_forecast = final_model.forecast(steps=forecast_days)
                    future_forecast.index = future_dates
                
                # Store in session state
                st.session_state.future_forecast = future_forecast
                st.session_state.best_model_name = best_model_name
                st.session_state.mae_ma = mae_ma
                st.session_state.mae_arima = mae_arima
                st.session_state.mae_es = mae_es
                st.session_state.forecasts_generated = True
                
                st.success(f"✅ Forecast berhasil! Model terbaik: {best_model_name}")
        
        if st.session_state.forecasts_generated:
            future_forecast = st.session_state.future_forecast
            best_model_name = st.session_state.best_model_name
            
            # Model performance
            st.subheader("🎯 Model Performance")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Model Terpilih", best_model_name)
            with col2:
                st.metric("Moving Avg MAE", f"£{st.session_state.mae_ma:,.0f}")
            with col3:
                st.metric("ARIMA MAE", f"£{st.session_state.mae_arima:,.0f}")
            with col4:
                st.metric("Exp. Smoothing MAE", f"£{st.session_state.mae_es:,.0f}")
            
            # Forecast visualization
            st.subheader("📈 Prediksi Revenue")
            
            fig = go.Figure()
            
            # Historical data
            fig.add_trace(go.Scatter(
                x=ts_data.index[-90:],  # Last 90 days
                y=ts_data['TotalRevenue'][-90:],
                mode='lines',
                name='Data Historis',
                line=dict(color='#1f77b4', width=2)
            ))
            
            # Future forecast
            fig.add_trace(go.Scatter(
                x=future_forecast.index,
                y=future_forecast,
                mode='lines+markers',
                name='Prediksi',
                line=dict(color='#ff7f0e', width=3, dash='dash'),
                marker=dict(size=6)
            ))
            
            # Confidence interval (simplified)
            std_error = ts_data['TotalRevenue'].std() * 0.1
            upper_bound = future_forecast + 1.96 * std_error
            lower_bound = future_forecast - 1.96 * std_error
            
            fig.add_trace(go.Scatter(
                x=future_forecast.index,
                y=upper_bound,
                mode='lines',
                line=dict(width=0),
                showlegend=False,
                hoverinfo='skip'
            ))
            
            fig.add_trace(go.Scatter(
                x=future_forecast.index,
                y=lower_bound,
                mode='lines',
                line=dict(width=0),
                fillcolor='rgba(255, 127, 14, 0.2)',
                fill='tonexty',
                name='95% Confidence Interval',
                hoverinfo='skip'
            ))
            
            fig.update_layout(
                height=500,
                hovermode='x unified',
                xaxis_title='Tanggal',
                yaxis_title='Revenue (£)'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Stock recommendations
            st.markdown("---")
            st.subheader("📦 Rekomendasi Stok Global")
            
            stock_rec = calculate_stock_recommendation(
                future_forecast,
                safety_stock_pct,
                lead_time_days
            )
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown('<div class="metric-card">', unsafe_allow_html=True)
                st.markdown(f"**Rata-rata Permintaan Harian**  \n\n£{stock_rec['avg_daily_demand']:,.0f}", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            with col2:
                st.markdown('<div class="metric-card">', unsafe_allow_html=True)
                st.markdown(f"**Safety Stock**  \n\n£{stock_rec['safety_stock']:,.0f}", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            with col3:
                st.markdown('<div class="metric-card">', unsafe_allow_html=True)
                st.markdown(f"**Reorder Point**  \n\n£{stock_rec['reorder_point']:,.0f}", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            with col4:
                st.markdown('<div class="metric-card">', unsafe_allow_html=True)
                st.markdown(f"**Stok Rekomendasi**  \n\n£{stock_rec['recommended_stock']:,.0f}", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
            
            # Interpretation
            st.info(f"""
            📋 **Interpretasi:**
            - **Reorder Point**: Pesan ulang ketika stok mencapai £{stock_rec['reorder_point']:,.0f}
            - **Safety Stock**: Simpan buffer £{stock_rec['safety_stock']:,.0f} untuk mengantisipasi lonjakan permintaan
            - **Total Stok Optimal**: £{stock_rec['recommended_stock']:,.0f} untuk {forecast_days} hari ke depan
            - **Lead Time**: {lead_time_days} hari (waktu tunggu pemesanan)
            """)
    
    # ========================================================================
    # TAB 3: MANAJEMEN PRODUK
    # ========================================================================
    with tab3:
        st.header("📦 Manajemen Produk Individual")
        
        # Filter by category
        category_filter = st.multiselect(
            "Filter Kategori",
            options=product_stats['Category'].unique(),
            default=product_stats['Category'].unique()
        )
        
        filtered_products = product_stats[product_stats['Category'].isin(category_filter)]
        
        # Product table
        st.subheader("📊 Daftar Produk")
        
        display_df = filtered_products[['ProductName', 'Category', 'TotalQuantity', 
                                       'TotalRevenue', 'AvgPrice']].copy()
        display_df['TotalRevenue'] = display_df['TotalRevenue'].apply(lambda x: f"£{x:,.0f}")
        display_df['AvgPrice'] = display_df['AvgPrice'].apply(lambda x: f"£{x:.2f}")
        display_df['TotalQuantity'] = display_df['TotalQuantity'].apply(lambda x: f"{x:,.0f}")
        
        st.dataframe(
            display_df.reset_index(drop=True),
            use_container_width=True,
            height=400
        )
        
        # Product-level forecast
        st.markdown("---")
        st.subheader("🔮 Forecast Per Produk")
        
        # Select top N products
        top_n = st.slider("Jumlah Produk Teratas", 5, 20, 10)
        
        if st.button("Generate Product Forecasts"):
            with st.spinner("Generating forecasts untuk produk..."):
                product_forecasts = {}
                
                for idx, row in product_stats.head(top_n).iterrows():
                    product_no = row['ProductNo']
                    product_name = row['ProductName']
                    
                    # Get product daily sales
                    product_df = df[df['ProductNo'] == product_no].copy()
                    product_daily = product_df.groupby('Date')['Quantity'].sum()
                    product_daily = product_daily.reindex(
                        pd.date_range(product_daily.index.min(), 
                                     product_daily.index.max(), 
                                     freq='D'),
                        fill_value=0
                    )
                    
                    # Simple forecast (moving average for speed)
                    window = min(7, len(product_daily) // 2)
                    if len(product_daily) > window:
                        forecast_qty = product_daily.rolling(window).mean().iloc[-1]
                        if pd.isna(forecast_qty):
                            forecast_qty = product_daily.mean()
                    else:
                        forecast_qty = product_daily.mean()
                    
                    product_forecasts[product_no] = {
                        'name': product_name,
                        'daily_forecast': forecast_qty,
                        '30day_forecast': forecast_qty * 30,
                        'safety_stock': forecast_qty * lead_time_days * (1 + safety_stock_pct/100)
                    }
                
                # Display forecasts
                forecast_df = pd.DataFrame([
                    {
                        'Product': v['name'][:40],
                        'Daily Demand': f"{v['daily_forecast']:.1f}",
                        '30-Day Demand': f"{v['30day_forecast']:.0f}",
                        'Safety Stock': f"{v['safety_stock']:.0f}",
                        'Total Stock Needed': f"{v['30day_forecast'] + v['safety_stock']:.0f}"
                    }
                    for k, v in product_forecasts.items()
                ])
                
                st.dataframe(forecast_df, use_container_width=True)
                
                # Download button
                csv = forecast_df.to_csv(index=False)
                st.download_button(
                    label="📥 Download Forecast CSV",
                    data=csv,
                    file_name="product_forecasts.csv",
                    mime="text/csv"
                )
    
    # ========================================================================
    # TAB 4: ALERT & REKOMENDASI
    # ========================================================================
    with tab4:
        st.header("⚠️ Alert & Rekomendasi Strategis")
        
        # Simulated current stock (in production, this would come from inventory DB)
        st.subheader("🏭 Simulasi Status Stok Saat Ini")
        st.info("💡 Dalam sistem produksi, data ini akan diambil dari database inventory real-time")
        
        # Generate sample current stock
        np.random.seed(42)
        stock_simulation = product_stats.head(20).copy()
        stock_simulation['CurrentStock'] = (
            stock_simulation['TotalQuantity'] * 
            np.random.uniform(0.3, 1.5, len(stock_simulation))
        ).astype(int)
        
        # Calculate optimal stock based on historical average
        daily_avg = df.groupby(['ProductNo', 'Date'])['Quantity'].sum().groupby('ProductNo').mean()
        stock_simulation['DailyAvg'] = stock_simulation['ProductNo'].map(daily_avg)
        stock_simulation['OptimalStock'] = (
            stock_simulation['DailyAvg'] * forecast_days * 
            (1 + safety_stock_pct/100)
        )
        stock_simulation['ReorderPoint'] = (
            stock_simulation['DailyAvg'] * lead_time_days * 
            (1 + safety_stock_pct/100)
        )
        stock_simulation['MaxStock'] = stock_simulation['OptimalStock'] * 1.5
        
        # Detect issues
        stock_simulation['Status'] = stock_simulation.apply(
            lambda row: detect_stock_issues(row['CurrentStock'], 
                                            row['ReorderPoint'], 
                                            row['MaxStock'])[0],
            axis=1
        )
        stock_simulation['StatusColor'] = stock_simulation.apply(
            lambda row: detect_stock_issues(row['CurrentStock'], 
                                            row['ReorderPoint'], 
                                            row['MaxStock'])[1],
            axis=1
        )
        
        # Count issues
        understock_count = (stock_simulation['Status'] == 'UNDERSTOCK').sum()
        overstock_count = (stock_simulation['Status'] == 'OVERSTOCK').sum()
        optimal_count = (stock_simulation['Status'] == 'OPTIMAL').sum()
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown('<div class="danger-box">', unsafe_allow_html=True)
            st.metric("🚨 UNDERSTOCK", understock_count)
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            st.markdown('<div class="warning-box">', unsafe_allow_html=True)
            st.metric("⚠️ OVERSTOCK", overstock_count)
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col3:
            st.markdown('<div class="success-box">', unsafe_allow_html=True)
            st.metric("✅ OPTIMAL", optimal_count)
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Detailed alerts
        st.markdown("---")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🚨 UNDERSTOCK ALERT")
            understock_items = stock_simulation[stock_simulation['Status'] == 'UNDERSTOCK']
            if len(understock_items) > 0:
                for idx, row in understock_items.iterrows():
                    shortage = row['ReorderPoint'] - row['CurrentStock']
                    st.error(f"""
                    **{row['ProductName'][:50]}**
                    - Current Stock: {row['CurrentStock']:.0f} units
                    - Reorder Point: {row['ReorderPoint']:.0f} units
                    - **⚠️ SHORTAGE: {shortage:.0f} units**
                    - 🎯 Action: ORDER {row['OptimalStock']:.0f} units
                    """)
            else:
                st.success("✅ Tidak ada produk understock")
        
        with col2:
            st.subheader("⚠️ OVERSTOCK ALERT")
            overstock_items = stock_simulation[stock_simulation['Status'] == 'OVERSTOCK']
            if len(overstock_items) > 0:
                for idx, row in overstock_items.iterrows():
                    excess = row['CurrentStock'] - row['MaxStock']
                    st.warning(f"""
                    **{row['ProductName'][:50]}**
                    - Current Stock: {row['CurrentStock']:.0f} units
                    - Max Stock: {row['MaxStock']:.0f} units
                    - **⚠️ EXCESS: {excess:.0f} units**
                    - 🎯 Action: PROMOSI atau DISKON
                    """)
            else:
                st.success("✅ Tidak ada produk overstock")
        
        # Strategic recommendations
        st.markdown("---")
        st.subheader("💡 Rekomendasi Strategis")
        
        recommendations = []
        
        # Understock recommendations
        if understock_count > 0:
            total_shortage = (stock_simulation[stock_simulation['Status'] == 'UNDERSTOCK']['ReorderPoint'] - 
                            stock_simulation[stock_simulation['Status'] == 'UNDERSTOCK']['CurrentStock']).sum()
            recommendations.append({
                'Priority': '🔴 HIGH',
                'Issue': 'Understock',
                'Action': f'Lakukan pemesanan segera untuk {understock_count} produk',
                'Impact': f'Mencegah kehilangan penjualan ~£{total_shortage * stock_simulation["AvgPrice"].mean():,.0f}'
            })
        
        # Overstock recommendations
        if overstock_count > 0:
            total_excess = (stock_simulation[stock_simulation['Status'] == 'OVERSTOCK']['CurrentStock'] - 
                          stock_simulation[stock_simulation['Status'] == 'OVERSTOCK']['MaxStock']).sum()
            recommendations.append({
                'Priority': '🟡 MEDIUM',
                'Issue': 'Overstock',
                'Action': f'Jalankan promosi untuk {overstock_count} produk',
                'Impact': f'Hemat biaya penyimpanan & kurangi risiko {total_excess:.0f} unit'
            })
        
        # Seasonal recommendations
        df['DayOfWeek'] = df['Date'].dt.day_name()
        dow_sales = df.groupby('DayOfWeek')['Revenue'].sum().sort_values(ascending=False)
        best_day = dow_sales.index[0]
        recommendations.append({
            'Priority': '🟢 LOW',
            'Issue': 'Seasonal Pattern',
            'Action': f'Fokus promosi di hari {best_day}',
            'Impact': f'Hari {best_day} menghasilkan revenue tertinggi'
        })
        
        # ABC focus
        a_products = (product_stats['Category'] == 'A - Best Sellers (Top 80%)').sum()
        recommendations.append({
            'Priority': '🟢 LOW',
            'Issue': 'Product Portfolio',
            'Action': f'Prioritaskan {a_products} produk kategori A',
            'Impact': 'Produk A menghasilkan 80% revenue'
        })
        
        rec_df = pd.DataFrame(recommendations)
        st.dataframe(rec_df, use_container_width=True, hide_index=True)
    
    # ========================================================================
    # TAB 5: ANALISIS DETAIL
    # ========================================================================
    with tab5:
        st.header("📊 Analisis Detail")
        
        # Seasonal analysis
        st.subheader("📅 Analisis Musiman")
        
        df['DayOfWeek'] = df['Date'].dt.day_name()
        df['Month'] = df['Date'].dt.month_name()
        df['IsWeekend'] = df['Date'].dt.dayofweek.isin([5, 6])
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Day of week
            dow_data = df.groupby('DayOfWeek')['Revenue'].sum().reindex([
                'Monday', 'Tuesday', 'Wednesday', 'Thursday', 
                'Friday', 'Saturday', 'Sunday'
            ])
            
            fig = go.Figure(data=[
                go.Bar(x=dow_data.index, y=dow_data.values,
                      marker_color='lightblue',
                      text=[f'£{v:,.0f}' for v in dow_data.values],
                      textposition='outside')
            ])
            fig.update_layout(
                title='Revenue per Hari',
                xaxis_title='Hari',
                yaxis_title='Revenue (£)',
                height=400
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Weekend vs Weekday
            weekend_data = df.groupby('IsWeekend')['Revenue'].sum()
            weekend_labels = ['Weekday', 'Weekend']
            
            fig = go.Figure(data=[
                go.Pie(labels=weekend_labels, values=weekend_data.values,
                      hole=0.4)
            ])
            fig.update_layout(
                title='Weekday vs Weekend Revenue',
                height=400
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Demand distribution
        st.markdown("---")
        st.subheader("📊 Distribusi Permintaan")
        
        fig = go.Figure()
        fig.add_trace(go.Histogram(
            x=ts_data['TotalRevenue'],
            nbinsx=30,
            name='Daily Revenue Distribution',
            marker_color='lightgreen'
        ))
        
        # Add mean and median lines
        mean_rev = ts_data['TotalRevenue'].mean()
        median_rev = ts_data['TotalRevenue'].median()
        
        fig.add_vline(x=mean_rev, line_dash="dash", line_color="red",
                     annotation_text=f"Mean: £{mean_rev:,.0f}")
        fig.add_vline(x=median_rev, line_dash="dash", line_color="blue",
                     annotation_text=f"Median: £{median_rev:,.0f}")
        
        fig.update_layout(
            title='Distribusi Revenue Harian',
            xaxis_title='Revenue (£)',
            yaxis_title='Frequency',
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Correlation analysis
        st.markdown("---")
        st.subheader("🔗 Korelasi Metrics")
        
        corr_data = ts_data[['TotalRevenue', 'TotalQuantity', 'NumTransactions']].corr()
        
        fig = go.Figure(data=go.Heatmap(
            z=corr_data.values,
            x=corr_data.columns,
            y=corr_data.columns,
            colorscale='RdBu',
            zmid=0,
            text=corr_data.values,
            texttemplate='%{text:.2f}',
            textfont={"size": 12}
        ))
        
        fig.update_layout(
            title='Correlation Matrix',
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
    <p>📦 Decision Support System - Inventory Management v1.0</p>
    <p>Developed for UAS DSS - Semester 5</p>
</div>
""", unsafe_allow_html=True)
